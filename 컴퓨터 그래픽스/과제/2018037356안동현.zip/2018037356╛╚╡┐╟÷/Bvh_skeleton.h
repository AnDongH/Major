#ifndef _BVH_H_
#define _BVH_H_

#include <vgl.h>
#include <mat.h>
#include <vector>

struct RPoint { /* Points for rendering. */
    vec4 Pt;
    vec3 Color;
};

struct RLine { /* Points for line. */
    vec4 EndPts[2];
    vec3 Color;
};

struct RTriangle { /* Points for triangle. */
    vec4 Pts[3];
    vec3 Color;
};

class TriMesh
{
public:
    int NumVertices;
    int NumTris;

    GLuint vao;
    GLuint vbo;
    GLuint ebo; // element buffer object for indices

    std::vector<vec4> vertices;
    std::vector<vec3> vnormals;

    vec3 color;
    mat4 modelTransform;

    std::vector<unsigned int> indices;

    /* other variables to use. */
    // Bounding box of the model
    vec3 BBoxMin; // the lower left corner of the bounding box 
    vec3 BBoxMax; // the upper right corner of the bounding box
    vec3 ObjCenter; // center point of the object

    TriMesh(); 
    ~TriMesh();
    void init();
    void Render(GLuint model);
    void ScaleObject();
protected:
    void BuildBoundingBox();
};

class AABBBox
{
public:
    vec3 BoxMin;
    vec3 BoxMax;
    int Id; /* Same as triangle index. */
};

class AABBNode
{
public:
    AABBNode *pLeftChild;
    AABBNode *pRightChild;
    const AABBBox **Boxes;
    int NumBoxes; // Number of triangles in this node

    vec3 BoxMin;
    vec3 BoxMax;

    AABBNode() {
        pLeftChild = pRightChild = NULL;
        NumBoxes = 0;
    }
    ~AABBNode() {
        if (pLeftChild != NULL)
            delete pLeftChild;
        if (pRightChild != NULL)
            delete pRightChild;
    }
    void SplitNode(const AABBBox **boxPtr, int Size);
};

class AABBBvh 
{
public:
    AABBNode *pRoot;
    
    /* Leaf geometry information. */
    AABBBox *Boxes;
    AABBBox **BoxPtrs;

    AABBBvh();
    ~AABBBvh();

    int BuildBvh(const TriMesh *mesh);
    
protected:
    const TriMesh *pMesh;    
};

/* Data structure for all other auxiliary geometries to be rendered. */
class AuxGeom
{
public:
    std::vector<RPoint> AuxPts;
    std::vector<RLine> AuxLines;
    std::vector<RTriangle> AuxTriangles;

    GLuint vao;
    GLuint vbos[3]; // 0 for points, 1 for lines, 2 for triangles
    bool RenderEnabled = false;

    void Init(); 
    void UpdateBuffer();

    void Render(GLuint modelLoc,mat4 const& m); 

    void RenderPoints(GLuint modelLoc,mat4 const& m); 
    void RenderLines(GLuint modelLoc,mat4 const& m); 
    void RenderTriangles(GLuint modelLoc,mat4 const& m); 

    void Destruct();  
    void AddPoints(const std::vector<vec4> &NewPts, bool UpdateVBO);
    void AddLines(const std::vector<std::pair<vec4, vec4> > &NewLines, bool UpdateVBO);
    void AddTriangles(const std::vector<vec4> &vertices, bool UpdateVBO);
    void Clear(bool UpdateVBO);
};

#endif

