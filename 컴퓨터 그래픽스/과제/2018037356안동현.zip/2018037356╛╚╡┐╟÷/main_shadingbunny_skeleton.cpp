#define _CRT_SECURE_NO_WARNINGS
#include <vgl.h>
#include <InitShader.h>
#include <mat.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "ObjLoader.h"
#include "Bvh_skeleton.h"
#include <queue>
#include <iostream>
#include <string>
using namespace std;

//viewing transformation parameters

GLfloat radius = 1.0;
GLfloat theta = 0.0;
GLfloat phi = 0.0;

const GLfloat dr = 5.0 * DegreesToRadians;

GLuint view; // model-view matrix uniform shader variable location
GLuint model;

// Projection transformation parameters
GLfloat fovy = 45.0; //field-of-view in y direction angle (in degrees)
GLfloat aspect; //Viewport aspect ratio
GLfloat zNear = 0.1, zFar = 10.0;
GLfloat winLeft = -2, winRight = 2, winBottom = -2, winTop = 2;
GLuint projection; //projection matrix uniform shader variable location

GLuint wired;
GLuint wireColor_loc;
GLuint colorAlpha_loc;

int BvhRenderDepth = 0;
int ShowMesh = 1;

TriMesh bunny;
AABBBvh *bunnyBvh = NULL;
AuxGeom auxGeom;
std::vector<AuxGeom *> bvs;
int curBvIndex = 0;
bool showBVH = true;
int rayCount = 0;

struct Plane {
    vec4 p;
    vec3 normal;
    float d() const { return dot(vec3(p.x, p.y, p.z), normal); }
};
Plane testPlane;

static int generate_random_rays(const vec4 StartPt, int NumRays, float RayR,
                                std::vector<std::pair<vec4, vec4> > &lines)
{
    for (int i = 0; i < NumRays; i++) {
        double theta = ((double)rand()) / RAND_MAX * 2.0 * M_PI; // theta in [0, 2pi]
        double phi = ((double)rand()) / RAND_MAX * M_PI - M_PI_2; // phi in [-pi/2, pi/2]

        vec4 EndPt;
        /* First calculate the direction of the ray. */
        EndPt[0] = RayR * cos(theta) * cos(phi);
        EndPt[1] = RayR * sin(theta) * cos(phi);
        EndPt[2] = RayR * sin(phi);
        EndPt[3] = 1.0;

        EndPt += StartPt;
        EndPt[3] = 1.0;
        lines.push_back(std::pair<vec4, vec4>(StartPt, EndPt));
    }

    return NumRays;
}

static void generate_aabb_lines(vec3 const &pmin, vec3 const &pmax, std::vector<std::pair<vec4, vec4>> &lines) {
    lines.emplace_back(vec4(pmin.x, pmin.y, pmin.z, 1), vec4(pmax.x, pmin.y, pmin.z, 1));
    lines.emplace_back(vec4(pmax.x, pmin.y, pmin.z, 1), vec4(pmax.x, pmax.y, pmin.z, 1));
    lines.emplace_back(vec4(pmax.x, pmax.y, pmin.z, 1), vec4(pmin.x, pmax.y, pmin.z, 1));
    lines.emplace_back(vec4(pmin.x, pmax.y, pmin.z, 1), vec4(pmin.x, pmin.y, pmin.z, 1));

    lines.emplace_back(vec4(pmin.x, pmin.y, pmax.z, 1), vec4(pmax.x, pmin.y, pmax.z, 1));
    lines.emplace_back(vec4(pmax.x, pmin.y, pmax.z, 1), vec4(pmax.x, pmax.y, pmax.z, 1));
    lines.emplace_back(vec4(pmax.x, pmax.y, pmax.z, 1), vec4(pmin.x, pmax.y, pmax.z, 1));
    lines.emplace_back(vec4(pmin.x, pmax.y, pmax.z, 1), vec4(pmin.x, pmin.y, pmax.z, 1));

    lines.emplace_back(vec4(pmin.x, pmin.y, pmin.z, 1), vec4(pmin.x, pmin.y, pmax.z, 1));
    lines.emplace_back(vec4(pmax.x, pmin.y, pmin.z, 1), vec4(pmax.x, pmin.y, pmax.z, 1));
    lines.emplace_back(vec4(pmax.x, pmax.y, pmin.z, 1), vec4(pmax.x, pmax.y, pmax.z, 1));
    lines.emplace_back(vec4(pmin.x, pmax.y, pmin.z, 1), vec4(pmin.x, pmax.y, pmax.z, 1));
}
float rayTriangularIntersect(vec3 const &o, vec3 const &d, int id) {
    vec4 q0 = bunny.vertices[bunny.indices[id * 3]];
    vec4 q1 = bunny.vertices[bunny.indices[id * 3 + 1]];
    vec4 q2 = bunny.vertices[bunny.indices[id * 3 + 2]];
    vec3 p0 = vec3(q0.x, q0.y, q0.z);
    vec3 p1 = vec3(q1.x, q1.y, q1.z);
    vec3 p2 = vec3(q2.x, q2.y, q2.z);

    const double kesi = 1e-8;
    vec3 e1 = p1 - p0;
    vec3 e2 = p2 - p0;
    vec3 q = cross(d, e2);
    auto a = dot(e1, q);
    if (abs(a) < 0) return -1;
    auto f = 1. / a;
    vec3 s = o - p0;
    auto u = f * dot(s, q);
    if (u < 0.) return -1;
    vec3 r = cross(s, e1);
    auto v = f * dot(d, r);
    if (v < 0. || (u + v) > 1.) return -1;
    auto t = f * dot(e2, r);
    return t;
}
float rayAABBIntersect(vec3 ro, vec3 rd, vec3 boxHalfSize) {
    vec3 m = vec3(1.0 / rd.x, 1.0 / rd.y, 1.0 / rd.z);
    vec3 n = m * ro;
    vec3 k = vec3(abs(m.x), abs(m.y), abs(m.z)) * boxHalfSize;
    vec3 t1 = -n - k;
    vec3 t2 = -n + k;
    float tN = max(max(t1.x, t1.y), t1.z);
    float tF = min(min(t2.x, t2.y), t2.z);

    if (abs(ro.x) < boxHalfSize.x && abs(ro.y) < boxHalfSize.y && abs(ro.z) < boxHalfSize.z) {
        if (tF > 0) return tF;
        return -1.;
    }

    if (tN > tF || tF < 0.) return -1.0;  // no intersection

    if (tN > 0) {
        return tN;
    } else if (tF > 0) {
        return tF;
    }
    return -1.;
}

int findNodeSplitAxis(AABBNode const *node) {
    vec3 BoxSize = (node->BoxMax - node->BoxMin) / 2;
    float LBoxSize = BoxSize[0];
    int LAxis = 0;

    for (int Axis = 1; Axis < 3; Axis++) {
        if (LBoxSize < BoxSize[Axis]) {
            LBoxSize = BoxSize[Axis];
            LAxis = Axis;
        }
    }
    return LAxis;
}

float rayBVHIntersectHelper(vec3 const &o, vec3 const &d, AABBNode const *node, int &faceIndex) {
    vec3 o2 = o - (node->BoxMin + node->BoxMax) / 2.;
    auto t = rayAABBIntersect(o2, d, (node->BoxMax - node->BoxMin) / 2.);
    if (t > 0) {
        if (node->pLeftChild || node->pRightChild) {
            AABBNode *tempNode;
            auto axis = findNodeSplitAxis(node);
            auto c = (node->BoxMax + node->BoxMin) / 2;
            if (o[axis] < c[axis]) {
                if (node->pLeftChild) t = rayBVHIntersectHelper(o, d, node->pLeftChild, faceIndex);
                if (t > 0) return t;
                if (node->pRightChild) t = rayBVHIntersectHelper(o, d, node->pRightChild, faceIndex);
                if (t > 0) return t;
            } else {
                if (node->pRightChild) t = rayBVHIntersectHelper(o, d, node->pRightChild, faceIndex);
                if (t > 0) return t;
                if (node->pLeftChild) t = rayBVHIntersectHelper(o, d, node->pLeftChild, faceIndex);
                if (t > 0) return t;
            }
        } else {
            // leaf
            for (int i = 0; i < node->NumBoxes; ++i) {
                o2 = o - (node->Boxes[i]->BoxMin + node->Boxes[i]->BoxMax) / 2.;
                t = rayAABBIntersect(o2, d, (node->Boxes[i]->BoxMax - node->Boxes[i]->BoxMin) / 2.);
                if (t > 0.) {
                    t = rayTriangularIntersect(o, d, node->Boxes[i]->Id);
                    if (t > 0) faceIndex = node->Boxes[i]->Id;
                }
            }
        }
    }
    return t;
}
bool rayBVHIntersect(vec4 a, vec4 b, vec4 &p, int &faceIndex) {
    auto transformInv = bunny.modelTransform;
    transformInv[0][0] = 1. / transformInv[0][0];
    transformInv[1][1] = 1. / transformInv[1][1];
    transformInv[2][2] = 1. / transformInv[2][2];
    transformInv[0][3] = -transformInv[0][3] * transformInv[0][0];
    transformInv[1][3] = -transformInv[1][3] * transformInv[1][1];
    transformInv[2][3] = -transformInv[2][3] * transformInv[2][2];
    a = transformInv * a;
    b = transformInv * b;

    vec3 ro = vec3(a.x, a.y, a.z);
    auto b2 = b - a;
    vec3 rd = normalize(vec3(b2.x, b2.y, b2.z));
    auto t = rayBVHIntersectHelper(ro, rd, bunnyBvh->pRoot, faceIndex);
    if (t < 0) return false;
    auto p2 = ro + t * rd;
    p = vec4(p2.x, p2.y, p2.z, 1);
    p = bunny.modelTransform * p;
    return true;
}
void linesIntersect(std::vector<std::pair<vec4, vec4>> const &lines) {
    auxGeom.AuxPts.clear();
    auxGeom.AuxTriangles.clear();
    std::vector<vec4> points;
    std::vector<vec4> vertices;
    for (auto &&e : lines) {
        vec4 p;
        int faceIndex;
        if (rayBVHIntersect(e.first, e.second, p, faceIndex)) {
            points.emplace_back(p);
            vertices.push_back(bunny.vertices[bunny.indices[faceIndex * 3]]);
            vertices.push_back(bunny.vertices[bunny.indices[faceIndex * 3 + 1]]);
            vertices.push_back(bunny.vertices[bunny.indices[faceIndex * 3 + 2]]);
        }
    }
    auxGeom.AddPoints(points, false);
    auxGeom.AddTriangles(vertices, true);
}
void generateRays() {
    std::vector<std::pair<vec4, vec4>> lines;
    auxGeom.Clear(false);
    generate_random_rays(vec4(0, 0, 0, 1), rayCount, 1.5, lines);

    auxGeom.AddLines(lines, true);
    linesIntersect(lines);
}
void updatePlane(vec4 const &offset);
void updateRays(vec4 const &offset) {
    if (rayCount > 0) {
        std::vector<std::pair<vec4, vec4>> lines;
        for (auto &&e : auxGeom.AuxLines) {
            e.EndPts[0] += offset;
            e.EndPts[1] += offset;
            lines.emplace_back(e.EndPts[0], e.EndPts[1]);
        }
        auxGeom.Clear(false);
        auxGeom.AddLines(lines, true);
        linesIntersect(lines);
    } else if (rayCount < 0) {
        updatePlane(offset);
    }
}

bool planeTriangleIntersect(Plane const &plane, int id, std::vector<vec4> &points) {
    vec4 q0 = bunny.vertices[bunny.indices[id * 3]];
    vec4 q1 = bunny.vertices[bunny.indices[id * 3 + 1]];
    vec4 q2 = bunny.vertices[bunny.indices[id * 3 + 2]];
    vec3 p0 = vec3(q0.x, q0.y, q0.z);
    vec3 p1 = vec3(q1.x, q1.y, q1.z);
    vec3 p2 = vec3(q2.x, q2.y, q2.z);
    auto d = plane.d();
    auto np0 = dot(plane.normal, p0);
    auto np1 = dot(plane.normal, p1);
    auto np2 = dot(plane.normal, p2);
    auto t = (d - np0) / (np1 - np0);
    std::vector<vec4> tempP;
    if (t > 0 && t < 1) tempP.emplace_back(p0 + t * (p1 - p0));

    t = (d - np2) / (np1 - np2);
    if (t > 0 && t < 1) tempP.emplace_back(p2 + t * (p1 - p2));

    t = (d - np0) / (np2 - np0);
    if (t > 0 && t < 1) tempP.emplace_back(p0 + t * (p2 - p0));
    if (tempP.size() == 2) {
        points.emplace_back(tempP[0]);
        points.emplace_back(tempP[1]);
        return true;
    }
    return false;
}
bool planeAABBIntersect(Plane const &plane, vec3 pmin, vec3 pmax) {
    vec3 c = (pmax + pmin) / 2;
    vec3 h = (pmax - pmin) / 2;
    auto e = dot(h, vec3(abs(plane.normal.x), abs(plane.normal.y), abs(plane.normal.z)));
    auto s = dot(c, plane.normal) - plane.d();
    return !(s - e > 0 || s + e < 0);
}
bool planesIntersectBVH(Plane const &plane, AABBNode const *node, std::vector<vec4> &points,
                        std::vector<int> &triangleIndices) {
    if (planeAABBIntersect(plane, node->BoxMin, node->BoxMax)) {
        if (node->pLeftChild || node->pRightChild) {
            if (node->pLeftChild) planesIntersectBVH(plane, node->pLeftChild, points, triangleIndices);
            if (node->pRightChild) planesIntersectBVH(plane, node->pRightChild, points, triangleIndices);
        } else {
            for (int i = 0; i < node->NumBoxes; ++i) {
                if (planeAABBIntersect(plane, node->Boxes[i]->BoxMin, node->Boxes[i]->BoxMax)) {
                    if (planeTriangleIntersect(plane, node->Boxes[i]->Id, points)) {
                        triangleIndices.emplace_back(node->Boxes[i]->Id);
                    }
                }
            }
        }
    }
    return false;
}

void planesIntersect() {
    auto transformInv = bunny.modelTransform;
    transformInv[0][0] = 1. / transformInv[0][0];
    transformInv[1][1] = 1. / transformInv[1][1];
    transformInv[2][2] = 1. / transformInv[2][2];
    transformInv[0][3] = -transformInv[0][3] * transformInv[0][0];
    transformInv[1][3] = -transformInv[1][3] * transformInv[1][1];
    transformInv[2][3] = -transformInv[2][3] * transformInv[2][2];

    //==================
    auxGeom.Clear(false);

    std::vector<vec4> vertices;

    std::vector<vec4> points;
    Plane testPlane2 = testPlane;
    testPlane2.p = transformInv * testPlane2.p;
    auto p = vec3(testPlane2.p.x, testPlane2.p.y, testPlane2.p.z);

    std::vector<int> trinalgeIndices;
    planesIntersectBVH(testPlane2, bunnyBvh->pRoot, points, trinalgeIndices);

    for (int i = 0; i < points.size(); i += 2) {
        RLine rline;
        rline.EndPts[0] = bunny.modelTransform * points[i];
        rline.EndPts[1] = bunny.modelTransform * points[i + 1];
        auxGeom.AuxLines.push_back(rline);
    }
    std::vector<vec4> trianglePoints;
    trianglePoints.reserve(trinalgeIndices.size() * 3);
    for (auto e : trinalgeIndices) {
        trianglePoints.emplace_back(bunny.vertices[bunny.indices[3 * e]]);
        trianglePoints.emplace_back(bunny.vertices[bunny.indices[3 * e + 1]]);
        trianglePoints.emplace_back(bunny.vertices[bunny.indices[3 * e + 2]]);
    }
    auxGeom.AddTriangles(trianglePoints, false);
    auxGeom.UpdateBuffer();
}
void updatePlane(vec4 const &offset) {
    if (rayCount < 0) {
        testPlane.p += offset;
        planesIntersect();
    }
}
void generatePlanes() {
    std::vector<std::pair<vec4, vec4>> lines;
    vec4 o{0, 0, 0, 1};
    generate_random_rays(o, 1, 1.5, lines);
    testPlane.p = o;
    auto n = normalize(lines[0].second - lines[0].first);
    testPlane.normal = vec3(n.x, n.y, n.z);
    planesIntersect();
}

void init(void) {
    CObjLoader *loader = new CObjLoader();
    if (!loader->Load("bunny_normals.obj", NULL)) {
        std::cout << "Cannot read the input obj file\n";
        delete loader;
        return;
    }

    if (loader->vertexes.size() != loader->normals.size()) {
        std::cout << "No vertex normals valid\n";
        delete loader;
        return;
    }
    bunny.NumVertices = loader->vertexes.size();
    bunny.NumTris = loader->parts[0].faces.size();
    
    bunny.vertices.resize(bunny.NumVertices);
    bunny.vnormals.resize(bunny.NumVertices);

    for (int i = 0; i < bunny.NumVertices; i++) {
        tVertex vtx = loader->getVertex(i),
            nrm = loader->normals[i];
        bunny.vertices[i] = vec4(vtx.x, vtx.y, vtx.z, 1.0);
        /* WARNINGS: bunny_normals.obj has INWARD normals, so the normal flipped! */
        bunny.vnormals[i] = -vec3(nrm.x, nrm.y, nrm.z);
    }

    bunny.indices.resize(bunny.NumTris * 3);
    for (int i = 0; i < bunny.NumTris; i++) {
        tFace *face = &(loader->parts[0].faces[i]);

        for (int j = 0; j < 3; j++)
            bunny.indices[3 * i + j] = (unsigned int)(face->v[j] - 1);
    }
    delete loader;

    //Set up shaders
    GLuint program = InitShader("vshader_shadingbunny.glsl", "fshader_shadingbunny.glsl");
    glUseProgram(program);

    bunny.init();
    bunny.ScaleObject(); 
   

    /* For BVH setting */
    bunnyBvh = new AABBBvh;
    bunnyBvh->BuildBvh(&bunny);

    /* For additional geometries to be rendered. */
    auxGeom.Init(); //show lines

    

    //add BV
    {
       std::vector<std::pair<vec4, vec4>> lines;
       std::queue<AABBNode *> nodes;
       nodes.emplace(bunnyBvh->pRoot);
    

       int count;
       while (!nodes.empty()) {
           count = nodes.size();
           lines.clear();
           while (count-- > 0) {
               auto node = nodes.front();
               nodes.pop();
               generate_aabb_lines(node->BoxMin, node->BoxMax, lines);

               if (node->pLeftChild) nodes.emplace(node->pLeftChild);
               if (node->pRightChild) nodes.emplace(node->pRightChild);
           }
           AuxGeom* p = new AuxGeom;
           p->Init();
           p->AddLines(lines, true);
           bvs.emplace_back(p);
       }
    }

   

    ///* test add points. */
    //{
    //    std::vector<vec4> transformed_pts;
    //    transformed_pts.resize(bunny.vertices.size());
    //    for (int i = 0; i < bunny.vertices.size(); i++)
    //        transformed_pts[i] = bunny.modelTransform * bunny.vertices[i];

    //    auxGeom.AddPoints(transformed_pts, true);
    //}

    ///* test lines. */
    // {
    //    std::vector<std::pair<vec4, vec4>> lines;
    //    generate_random_rays(vec4(0, 0, 0, 1), 5, 1.5, lines);
    //    auxGeom.AddLines(lines, true);
    // }

    ///* test triangles. */
    // {
    //    std::vector<vec4> vertices{
    //     {0,0,0,1},
    //     {1,0,0,1},
    //     {0,1,0,1},
    //    };
    //    auxGeom.AddTriangles(vertices, true);
    // }


    //initialize vertex position attribute from vertex shader
    vec4 light_position( 0.0, 0.0, -1.0, 0.0 );
    vec4 light_ambient( 0.2, 0.2, 0.2, 1.0 );
    vec4 light_diffuse( 1.0, 1.0, 1.0, 1.0 );
    vec4 light_specular( 1.0, 1.0, 1.0, 1.0 );

    vec4 material_ambient( 1.0, 0.0, 1.0, 1.0 );
    vec4 material_diffuse( 1.0, 0.8, 0.0, 1.0 );
    vec4 material_specular( 1.0, 0.8, 0.0, 1.0 );
    float  material_shininess = 100.0;

    vec4 ambient_product = light_ambient * material_ambient;
    vec4 diffuse_product = light_diffuse * material_diffuse;
    vec4 specular_product = light_specular * material_specular;

    glUniform4fv( glGetUniformLocation(program, "AmbientProduct"),
		  1, ambient_product );
    glUniform4fv( glGetUniformLocation(program, "DiffuseProduct"),
		  1, diffuse_product );
    glUniform4fv( glGetUniformLocation(program, "SpecularProduct"),
		  1, specular_product );
	
    glUniform4fv( glGetUniformLocation(program, "LightPosition"),
		  1, light_position );

    glUniform1f( glGetUniformLocation(program, "Shininess"),
		 material_shininess );

    //initialize uniform variable from vertex shander
    model = glGetUniformLocation(program, "model");
    view = glGetUniformLocation(program, "view");
    projection = glGetUniformLocation(program, "projection");

    wired = glGetUniformLocation(program, "wired");
    wireColor_loc = glGetUniformLocation(program, "WireColor");
    colorAlpha_loc = glGetUniformLocation(program, "colorAlpha");
    
    glEnable(GL_DEPTH_TEST);
    glClearColor(1.0, 1.0, 1.0, 0.0);

   
}

void display()
{
    glClear( GL_COLOR_BUFFER_BIT  | GL_DEPTH_BUFFER_BIT );

    vec4 eye( radius * sin(theta) * cos(phi),
              radius * sin(theta) * sin(phi),
              radius * cos(theta),
              1.0);
    vec4 at(0.0, 0.0, 0.0, 1.0);
    vec4 up(0.0, 1.0, 0.0, 0.0);

    mat4 vmat = LookAt(eye, at, up);
    glUniformMatrix4fv(view, 1, GL_TRUE, vmat);

    mat4 p = Perspective(fovy, aspect, zNear, zFar);
    //mat4 p = Ortho(winLeft, winRight, winBottom, winTop, zNear, zFar);

    glUniformMatrix4fv(projection, 1, GL_TRUE, p);

    if (ShowMesh) {
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glEnable(GL_POLYGON_OFFSET_FILL);
        glPolygonOffset(1.0, 1.0);

        glUniform1i(wired, 0);
        glUniform1f(colorAlpha_loc, 0.5);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        bunny.Render(model);
        glDisable(GL_BLEND);
    }

    /* Draw edges of the bunny. */
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    
    glUniform1i(wired, 1);
    glUniform3fv(wireColor_loc, 1, vec3(0.0, 0.0, 0.0));
    glUniform1f(colorAlpha_loc, 0.8);

    bunny.Render(model);

    if (bunnyBvh != NULL) {
        // draw bunny bvh
    }

    

    glUniform1i(wired, 1);

    glUniform3fv(wireColor_loc, 1, vec3(0.0, 1.0, 1.0));
    glUniform1f(colorAlpha_loc, 1.0);

    glPolygonOffset(-0.1, 0);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    auxGeom.RenderTriangles(model, bunny.modelTransform);
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    glPolygonOffset(-1, 0);
    glUniform3fv(wireColor_loc, 1, vec3(1.0, 0.0, 0.0));
    auxGeom.RenderLines(model, mat4());


    glUniform3fv(wireColor_loc, 1, vec3(0.0, 0.0, 1.0));
    glPolygonOffset(-2, 0);
    auxGeom.RenderPoints(model, mat4());

    glPolygonOffset(0, 0);

    if (showBVH) {
        glUniform3fv(wireColor_loc, 1, vec3(0.0, 1.0, 0.0));
        bvs[curBvIndex]->Render(model, bunny.modelTransform);
    }
    

    glutSwapBuffers();

   
}

void keyboard( unsigned char key, int x, int y )
{
    static float step=0.1;
    switch (key) {
        case 033:
            exit(EXIT_SUCCESS);
            break;
        case 'x': {
            updateRays(vec4(step, 0, 0, 0));
            break;
        }
        case 'X': {
            updateRays(vec4(-step, 0, 0, 0));
            break;
        }
        case 'y': {
            updateRays(vec4(0, step, 0, 0));
            break;
        }
        case 'Y': {
            updateRays(vec4(0, -step, 0, 0));
            break;
        }
        case 'z': {
            updateRays(vec4(0, 0, step, 0));
            break;
        }
        case 'Z': {
            updateRays(vec4(0, 0, -step, 0));
            break;
        }
        // case 'z': zNear *= 1.1; zFar *= 1.1; break;
        // case 'Z': zNear *= 0.9; zFar *= 0.9; break;
        case 'r':
            radius *= 2.0;
            break;
        case 'R':
            radius *= 0.5;
            break;
        case 'o':
            theta += dr;
            break;
        case 'O':
            theta -= dr;
            break;
        case 'p':
            phi += dr;
            break;
        case 'P':
            phi -= dr;
            break;
        case 's':
            showBVH = !showBVH;
            break;
        case '1':
            std::cout << "please set ray count: ";
            std::cin >> rayCount;
            std::cout << "\ncurrent ray count is: " << rayCount << std::endl;
            generateRays();
            break;
        case '2':
            rayCount = -1;
            generatePlanes();
            break;

        case ' ':  // reset values to their defaults
            zNear = 0.5;
            zFar = 3.0;

            radius = 1.0;
            theta = 0.0;
            phi = 0.0;
            break;
    }
    glutPostRedisplay();
}

void specialkey(int key, int x, int y)
{
    switch (key) {
    case GLUT_KEY_UP:
        --curBvIndex;
        curBvIndex = std::max(0, curBvIndex);
        break;
    case GLUT_KEY_DOWN:
        ++curBvIndex;
        curBvIndex = std::min(int(bvs.size()-1), curBvIndex);
        break;
    case GLUT_KEY_LEFT:
        ShowMesh = 1;
        break;
    case GLUT_KEY_RIGHT:
        ShowMesh = 0;
        break;
    }
    glutPostRedisplay();
}

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    aspect = GLfloat(width) / height;
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitContextVersion(3, 3);
    glutInitContextFlags(GLUT_CORE_PROFILE);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_SRGB);
    glutInitWindowSize(512, 512);

    aspect = 512.0 / 512.0;

    glutCreateWindow("2018037356�ȵ���");

    // seed values for random numbers
    srand((unsigned)time(NULL));

    auto err = glewInit();
    if (err != GLEW_OK) {
        fprintf(stderr,"failed to init glew");
        exit(-1);
    }

    init();
   
    /*
    printf("OpenGL %s, GLSL %s\n",                         
	    glGetString(GL_VERSION),
            glGetString(GL_SHADING_LANGUAGE_VERSION));
    */

    glutDisplayFunc(display);
    glutKeyboardFunc( keyboard );
    glutSpecialFunc(specialkey);
    glutMainLoop();

    if (bunnyBvh != NULL) {
        delete bunnyBvh;
    }

    return 0;
}