// #include "Bvh.h"
#include "Bvh_skeleton.h"

#include <float.h>

#include <cassert>
#include <cstdio>
#include <cstdlib>

#define EPS 1e-6

static vec4 cube_vertices[8] = {
    vec4(0.0, 0.0,  1.0, 1.0),
    vec4(0.0,  1.0,  1.0, 1.0),
    vec4(1.0,  1.0,  1.0, 1.0),
    vec4(1.0, 0.0,  1.0, 1.0),
    vec4(0.0, 0.0, 0.0, 1.0),
    vec4(0.0,  1.0, 0.0, 1.0),
    vec4(1.0,  1.0, 0.0, 1.0),
    vec4(1.0, 0.0, 0.0, 1.0)
};

static void quad(int a, int b, int c, int d,
                 std::vector<vec4> &points,
                 std::vector<vec3> &normals)
{
    // Initialize temporary vectors along the quad's edge to
    //   compute its face normal 
    vec4 u = cube_vertices[b] - cube_vertices[a];
    vec4 v = cube_vertices[c] - cube_vertices[b];

    vec3 normal = normalize(cross(u, v));

    normals.push_back(normal); points.push_back(cube_vertices[a]);
    normals.push_back(normal); points.push_back(cube_vertices[b]); 
    normals.push_back(normal); points.push_back(cube_vertices[c]);
    normals.push_back(normal); points.push_back(cube_vertices[d]);
}

TriMesh::TriMesh()
{
    NumVertices = 0;
    NumTris = 0;
}

TriMesh::~TriMesh()
{
    glDeleteBuffers(1, &vbo);
    glDeleteBuffers(1, &ebo);
    glDeleteVertexArrays(1, &vao);
}

void TriMesh::init()
{
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glGenBuffers(1, &ebo);

    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, 
                 sizeof(vec4) * vertices.size() + sizeof(vec3) * vnormals.size(),
                 NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vec4) * vertices.size(), vertices.data());
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(vec4) * vertices.size(),
                    sizeof(vec3) * vnormals.size(), vnormals.data());

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * indices.size(), indices.data(),
                 GL_STATIC_DRAW);
    glBindVertexArray(0);
}

void TriMesh::Render(GLuint model)
{
    //set a constant color
    glUniformMatrix4fv(model, 1, GL_TRUE, modelTransform);

    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0,
                          BUFFER_OFFSET(sizeof(vec4) * vertices.size()));

    glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

void TriMesh::BuildBoundingBox() {
    if (vertices.empty())
        return;

    BBoxMin = vec3(FLT_MAX, FLT_MAX, FLT_MAX);
    BBoxMax = vec3(-FLT_MAX, -FLT_MAX, -FLT_MAX);

    for (size_t i = 0; i < vertices.size(); i++) {
        for (int k = 0; k < 3; k++) {
            if (vertices[i][k] < BBoxMin[k])
                BBoxMin[k] = vertices[i][k];
            if (vertices[i][k] > BBoxMax[k])
                BBoxMax[k] = vertices[i][k];
        }
    }
    ObjCenter = (BBoxMin + BBoxMax) * 0.5;
}

void TriMesh::ScaleObject() {
    BuildBoundingBox();

    /* Find the longest length of the bounding box. */
    vec3 ObjScale = BBoxMax - BBoxMin;
    float maxScale = -1;
    for (int k = 0; k < 3; k++) {
        if (ObjScale[k] > maxScale)
            maxScale = ObjScale[k];
    }

    /* Scale the object by the longest length of its bounding box. */
    modelTransform = Scale(1 / maxScale) * Translate(-ObjCenter[0], -ObjCenter[1], -ObjCenter[2]);
}

/* Axis-aligned bounding box for the triangular mesh. */
void AABBNode::SplitNode(const AABBBox **boxPtr, int Size)
{
    if (Size == 0) {
        return;
    }

    Boxes = boxPtr;
    NumBoxes = Size;

    vec3 Center, Min, Max;
    
    /* Compute the bounding box of object arrays with Size triangles. */
    Min = vec3(FLT_MAX, FLT_MAX, FLT_MAX);
    Max = vec3(-FLT_MAX, -FLT_MAX, -FLT_MAX);
    
    /* Find the midpoint m of bounding box of A along Axis. */
    for (int i = 0; i < Size; i++) {
        for (int Axis = 0; Axis < 3; Axis++) {
            if (Boxes[i] -> BoxMin[Axis] < Min[Axis])
                Min[Axis] = Boxes[i] -> BoxMin[Axis];
            if (Boxes[i] -> BoxMax[Axis] > Max[Axis])
                Max[Axis] = Boxes[i] -> BoxMax[Axis];
        }
    }
    
    BoxMin = Min;
    BoxMax = Max;

    if (Size == 1)
        return;
    
    /* When there exists more than one boxes in this node. */
    Center = (Min + Max) * 0.5;

    vec3 BoxSize = Max - Center;
    float LBoxSize = BoxSize[0];
    int LAxis = 0;

    for (int Axis = 1; Axis < 3; Axis++) {
        if (LBoxSize < BoxSize[Axis]) {
            LBoxSize = BoxSize[Axis];
            LAxis = Axis;
        }
    }
    
    /* Partition A into lists with length=k and (N-k) */
    float MidVal = Center[LAxis];
    
    int Lesser = 0,
        Greater = 0,
        Tested = 0,
        k = 0;
    while (Tested < Size) {
        float Val = (Boxes[k]-> BoxMax[LAxis] + Boxes[k]-> BoxMin[LAxis]) * 0.5;
        if (Val > MidVal) {
            /* Move the element to the end of the array. */
            int Idx = Size - 1 - Greater;
            const AABBBox *Temp = Boxes[Idx];
            Boxes[Idx] = Boxes[k];
            Boxes[k] = Temp;
            Greater++;
        }
        else if (Val < MidVal) {
            /* Move the element to the front of the array. */
            const AABBBox *Temp = Boxes[Lesser];
            Boxes[Lesser] = Boxes[k];
            Boxes[k] = Temp;
            Lesser++;
            k++;
        }
        else {
            /* Skip to the next element when Val == MidVal */
            k++;
        }
        Tested++;
    }
    
    /* Distribute the equal element to both lesser and greater side. */
    int Equal = Size - Lesser - Greater;
    if (Equal % 2 == 0) {
        Lesser += Equal / 2;
        Greater += Equal / 2;
    }
    else {
        if (Lesser > Greater) {
            Lesser += Equal / 2;
            Greater += (Equal / 2 + 1);
        }
        else {
            Lesser += (Equal / 2 + 1);
            Greater += Equal / 2;
        }
    }

    assert(Lesser != 0 && Greater != 0);

    if (Lesser > 0) {
        pLeftChild = new AABBNode;
        pLeftChild -> SplitNode(&(Boxes[0]), Lesser);
    }

    if (Greater > 0) {
        pRightChild = new AABBNode;
        pRightChild -> SplitNode(&(Boxes[Lesser]), Greater);
    }
}

AABBBvh::AABBBvh()
{
    pRoot = NULL;
    Boxes = NULL;
    BoxPtrs = NULL;
}

AABBBvh::~AABBBvh()
{
    if (pRoot != NULL) 
        delete pRoot;
    if (BoxPtrs != NULL)
        delete[] BoxPtrs;
    if (Boxes != NULL)
        delete[] Boxes;
}

int AABBBvh::BuildBvh(const TriMesh *mesh)
{
    if (mesh == NULL)
        return 0;

    pMesh = mesh;

    int NumTris = pMesh -> NumTris;
    Boxes = new AABBBox[NumTris];
    BoxPtrs = new AABBBox *[NumTris];

    /* Construct aabb for each triangle. */
    for (int i = 0; i < NumTris; i++) {
        Boxes[i].BoxMin = vec3(FLT_MAX, FLT_MAX, FLT_MAX);
        Boxes[i].BoxMax = vec3(-FLT_MAX, -FLT_MAX, -FLT_MAX);

        for (int j = 0; j < 3; j++) {
            int vIdx = pMesh -> indices[i * 3 + j];
            const vec4 pt = pMesh -> vertices[vIdx];

            for (int Axis = 0; Axis < 3; Axis++) {
                if (pt[Axis] < Boxes[i].BoxMin[Axis])
                    Boxes[i].BoxMin[Axis] = pt[Axis];
                if (pt[Axis] > Boxes[i].BoxMax[Axis])
                    Boxes[i].BoxMax[Axis] = pt[Axis];
            }
        }

        /* Make the bounding box slightly larger than the original triangle. */
        for (int Axis = 0; Axis < 3; Axis++) {
            Boxes[i].BoxMin[Axis] -= EPS;
            Boxes[i].BoxMax[Axis] += EPS;
        }
        Boxes[i].Id = i;
        BoxPtrs[i] = &(Boxes[i]);
    }

    pRoot = new AABBNode;
    pRoot -> SplitNode((const AABBBox **)BoxPtrs, NumTris);
   
    return 1;
}

/***********************/
void AuxGeom::Init()
{
    glGenVertexArrays(1, &vao);
    glGenBuffers(3, vbos);

    UpdateBuffer();

    glBindVertexArray(0);
}

void AuxGeom::UpdateBuffer()
{
    std::vector<vec4> TempPts;

    glBindVertexArray(vao);

    /* for point data. */
    TempPts.resize(AuxPts.size());
    for (int i = 0; i < AuxPts.size(); i++)
        TempPts[i] = AuxPts[i].Pt;

    glBindBuffer(GL_ARRAY_BUFFER, vbos[0]);
    glBufferData(GL_ARRAY_BUFFER,
                 sizeof(vec4) * TempPts.size(), TempPts.data(),
                 GL_STATIC_DRAW);

    /* for line data. */
    TempPts.resize(AuxLines.size() * 2);
    for (int i = 0; i < AuxLines.size(); i++) {
        TempPts[2 * i] = AuxLines[i].EndPts[0];
        TempPts[2 * i + 1] = AuxLines[i].EndPts[1];
    }

    glBindBuffer(GL_ARRAY_BUFFER, vbos[1]);
    glBufferData(GL_ARRAY_BUFFER,
                 sizeof(vec4) * TempPts.size(), TempPts.data(),
                 GL_STATIC_DRAW);

    /* for triangle data. */
    TempPts.resize(AuxTriangles.size() * 3);
    for (int i = 0; i < AuxTriangles.size(); i++) {
        TempPts[3 * i] = AuxTriangles[i].Pts[0];
        TempPts[3 * i + 1] = AuxTriangles[i].Pts[1];
        TempPts[3 * i + 2] = AuxTriangles[i].Pts[2];
    }

    glBindBuffer(GL_ARRAY_BUFFER, vbos[2]);
    glBufferData(GL_ARRAY_BUFFER,
                 sizeof(vec4) * TempPts.size(), TempPts.data(),
                 GL_STATIC_DRAW);
    
    glBindVertexArray(0);
}

void AuxGeom::Render(GLuint modelLoc,mat4 const& m)
{
    glUniformMatrix4fv(modelLoc, 1, GL_TRUE, m);

    glBindVertexArray(vao);

    /* draw points. */
    if (!AuxPts.empty()) {
        glBindBuffer(GL_ARRAY_BUFFER, vbos[0]);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

        glPointSize(5.0f);
        glDrawArrays(GL_POINTS, 0, AuxPts.size());
    }
    /* draw lines. */
    if (!AuxLines.empty()) {
        glBindBuffer(GL_ARRAY_BUFFER, vbos[1]);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

        glDrawArrays(GL_LINES, 0, AuxLines.size() * 2);
    }
    /* draw triangles. */
    if (!AuxTriangles.empty()) {
        glBindBuffer(GL_ARRAY_BUFFER, vbos[2]);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

        glDrawArrays(GL_TRIANGLES, 0, AuxTriangles.size());
    }
    glBindVertexArray(0);
}
void AuxGeom::RenderPoints(GLuint modelLoc,mat4 const& m)
{
    glUniformMatrix4fv(modelLoc, 1, GL_TRUE, m);

    glBindVertexArray(vao);

    /* draw points. */
    if (!AuxPts.empty()) {
        glBindBuffer(GL_ARRAY_BUFFER, vbos[0]);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

        glPointSize(5.0f);
        glDrawArrays(GL_POINTS, 0, AuxPts.size());
    }
    glBindVertexArray(0);
}
void AuxGeom::RenderLines(GLuint modelLoc,mat4 const& m)
{
    glUniformMatrix4fv(modelLoc, 1, GL_TRUE, m);

    glBindVertexArray(vao);

    /* draw lines. */
    if (!AuxLines.empty()) {
        glBindBuffer(GL_ARRAY_BUFFER, vbos[1]);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

        glDrawArrays(GL_LINES, 0, AuxLines.size() * 2);
    }
    glBindVertexArray(0);

}
void AuxGeom::RenderTriangles(GLuint modelLoc,mat4 const& m)
{
    glUniformMatrix4fv(modelLoc, 1, GL_TRUE, m);

    glBindVertexArray(vao);

    /* draw triangles. */
    if (!AuxTriangles.empty()) {
        glBindBuffer(GL_ARRAY_BUFFER, vbos[2]);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

        glDrawArrays(GL_TRIANGLES, 0, AuxTriangles.size() * 3);
    }
    glBindVertexArray(0);
}

void AuxGeom::Destruct() 
{
    glDeleteBuffers(3, vbos);
    glDeleteVertexArrays(1, &vao);
}

void AuxGeom::AddPoints(const std::vector<vec4> &NewPts, bool UpdateVBO)
{
    int NumNewPts = NewPts.size();
    for (int i = 0; i < NumNewPts; i++) {
        RPoint rpt;
        rpt.Pt = NewPts[i];
        AuxPts.push_back(rpt);
    }

    if (UpdateVBO)
        UpdateBuffer();
}

void AuxGeom::AddLines(const std::vector<std::pair<vec4, vec4> > &NewLines, bool UpdateVBO)
{
    int NumNewLines = NewLines.size();
    for (int i = 0; i < NumNewLines; i++) {
        RLine rline;
        rline.EndPts[0] = NewLines[i].first;
        rline.EndPts[1] = NewLines[i].second;
        AuxLines.push_back(rline);
    }

    if (UpdateVBO)
        UpdateBuffer();
}
void AuxGeom::AddTriangles(const std::vector<vec4> &vertices, bool UpdateVBO) {
    for (int i = 0; i < vertices.size(); i += 3) {
        RTriangle rtriangle;
        rtriangle.Pts[0] = vertices[i + 0];
        rtriangle.Pts[1] = vertices[i + 1];
        rtriangle.Pts[2] = vertices[i + 2];
        AuxTriangles.push_back(rtriangle);
    }
    if (UpdateVBO) UpdateBuffer();
}
void AuxGeom::Clear(bool UpdateVBO) {
    AuxPts.clear();
    AuxLines.clear();
    AuxTriangles.clear();
    if (UpdateVBO) UpdateBuffer();
}